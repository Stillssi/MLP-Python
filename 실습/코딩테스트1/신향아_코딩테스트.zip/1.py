def solution(lottos, win_nums):
    answer = []
    cnt = 0 
    zero = 0
    for lotto in lottos:
        if lotto == 0:
            zero += 1
        for win_num in win_nums:
            if lotto == win_num:
                   cnt += 1
    answer.append(7-(cnt+zero))
    if 7-cnt >= 6:
        answer.append(6)
    else:
        answer.append(7-cnt)

    return answer