def solution(id_list, report, k):
    answer = [0 for i in range(len(id_list))]
    declaration_dict={id:0 for id in id_list}

    print(declaration_dict)
    for i in range(len(id_list)):
        for j in range(len(id_list)):
            if id_list[i]+" "+id_list[j] in report:
                declaration_dict[id_list[j]] += 1
                
    for i in range(len(id_list)):
        if declaration_dict[id_list[i]] >= 2:
            for j in range(len(id_list)):
                if id_list[j]+" "+id_list[i] in report:
                    print(id_list[j]+" "+id_list[i])
                    answer[j] += 1
    return answer